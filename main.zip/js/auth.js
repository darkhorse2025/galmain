const firebaseConfig = {
    apiKey: "AIzaSyDtNedkJo6ikNneZZdrheiWbE3Dn2B8kwQ",
    authDomain: "ces-project-f8b4e.firebaseapp.com",
    databaseURL: "https://ces-project-f8b4e-default-rtdb.asia-southeast1.firebasedatabase.app",
    projectId: "ces-project-f8b4e",
    storageBucket: "ces-project-f8b4e.firebasestorage.app",
    messagingSenderId: "580767851656",
    appId: "1:580767851656:web:d9113b8b64ec1ff3cdeb3d",
    measurementId: "G-FVXFP9ZQKC"
};

// Initialize Firebase
firebase.initializeApp(firebaseConfig);

// Function to send verification code using Firebase OTP
function sendVerificationCode() {
    let phoneNumber = document.getElementById('phoneNumber').value;
    if (!phoneNumber) {
        showSnackbar("Please enter a phone number.");
        return;
    }

    let provider = "GALA"; // Set SMS provider title

    // reCAPTCHA verifier
    window.recaptchaVerifier = new firebase.auth.RecaptchaVerifier('sign-in-button', {
        'size': 'invisible',
    });

    var appVerifier = window.recaptchaVerifier;

    firebase.auth().signInWithPhoneNumber(phoneNumber, appVerifier)
        .then(function (confirmationResult) {
            window.confirmationResultGlobal = confirmationResult;
            startOTPTimer(); // Start 120-second countdown
            showSnackbar('OTP sent via ' + provider);
        }).catch(function (error) {
            console.error("Error sending verification code:", error);
            showSnackbar('Error sending OTP: ' + error.message);
            window.recaptchaVerifier.render().then(function (widgetId) {
                grecaptcha.reset(widgetId);
            });
        });
}

// Function to verify OTP
function verifyOTP() {
    let verificationCode = document.getElementById('otpCode').value;
    if (!verificationCode) {
        showSnackbar("Please enter the OTP.");
        return;
    }

    window.confirmationResultGlobal.confirm(verificationCode)
        .then(function (result) {
            showSnackbar("OTP Verified Successfully!");
            // Redirect or proceed with login actions
            window.location.href = "index.html";
        }).catch(function (error) {
            showSnackbar("Invalid OTP. Try again.");
            console.error("OTP Verification Error:", error);
        });
}

// Function to start the 120-second timer for OTP expiration
function startOTPTimer() {
    let otpTimer = 120; // Set to 120 seconds
    const timerDisplay = document.getElementById("otp-timer"); // Element to display countdown
    if (timerDisplay) {
        const countdown = setInterval(() => {
            if (otpTimer <= 0) {
                clearInterval(countdown);
                showSnackbar("OTP Expired. Request a new one.");
                timerDisplay.textContent = "OTP Expired";
            } else {
                timerDisplay.textContent = `OTP Expires in ${otpTimer} seconds`;
            }
            otpTimer--;
        }, 1000);
    }
}

// Snackbar function
function showSnackbar(message) {
    var snackbar = document.getElementById("snackbar");
    snackbar.innerText = message;
    snackbar.className = "snackbar show";
    setTimeout(function () { snackbar.className = snackbar.className.replace("show", ""); }, 3000);
}